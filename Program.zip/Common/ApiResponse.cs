// Path: Common/ApiResponse.cs
using System.Collections.Generic;

namespace RhSensoWeb.Common
{
    /// <summary>
    /// Envelope padr�o para respostas JSON.
    /// Serializa como { success, message, data } (camelCase por padr�o no ASP.NET Core).
    /// </summary>
    public record ApiResponse(bool Success, string? Message = null, object? Data = null)
    {
        /// <summary>Cria uma resposta de sucesso.</summary>
        public static ApiResponse Ok(string? message = null, object? data = null)
            => new(true, message, data);

        /// <summary>Cria uma resposta de falha.</summary>
        public static ApiResponse Fail(string? message = null, object? data = null)
            => new(false, message, data);

        /// <summary>
        /// Auxiliar para incluir erros de valida��o.
        /// Data recebe um dicion�rio: { "Campo": ["Erro1", "Erro2"] }
        /// </summary>
        public static ApiResponse Validation(string? message, IDictionary<string, string[]> errors)
            => new(false, message, errors);

        // --- Wrappers opcionais p/ compatibilidade sem ambiguidade de nomes ---
        // Evitamos "Success(...)" para n�o colidir com a propriedade Success (e gerar CS1955).
        public static ApiResponse SuccessMsg(string? message = null, object? data = null) => Ok(message, data);
        public static ApiResponse Error(string? message = null, object? data = null) => Fail(message, data);
    }

    /// <summary>
    /// Vers�o gen�rica quando voc� quer tipar o "data".
    /// </summary>
    public record ApiResponse<T>(bool Success, string? Message = null, T? Data = default)
    {
        public static ApiResponse<T> Ok(T data, string? message = null)
            => new(true, message, data);

        public static ApiResponse<T> Fail(string? message = null, T? data = default)
            => new(false, message, data);
    }
}
