using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System.Reflection;

using RhSensoWeb.Common;
using RhSensoWeb.Models;
using RhSensoWeb.Filters;              // RequirePermission
using RhSensoWeb.Services.Security;    // IRowTokenService
using RhSensoWeb.Areas.SEG.Services;   // ITsistemaService

namespace RhSensoWeb.Areas.SEG.Controllers
{
    [Area("SEG")]
    [Authorize]
    public class TsistemaController : Controller
    {
        private readonly ITsistemaService _service;
        private readonly ILogger<TsistemaController> _logger;
        private readonly IRowTokenService _rowToken;
        private readonly IMemoryCache _cache;

        public TsistemaController(
            ITsistemaService service,
            ILogger<TsistemaController> logger,
            IRowTokenService rowToken,
            IMemoryCache cache)
        {
            _service = service;
            _logger = logger;
            _rowToken = rowToken;
            _cache = cache;
        }

        // ===== Payload do token p/ ações de linha =====
        public sealed record RowKeys(string Cdsistema);

        // GET: /SEG/Tsistema
        [HttpGet]
        [RequirePermission("SEG", "SEG_SISTEMAS", "I")]
        public IActionResult Index() => View();

        // GET: /SEG/Tsistema/GetData
        // Retorno para DataTables: { data: [...] }
        [HttpGet]
        [RequirePermission("SEG", "SEG_SISTEMAS", "I")]
        public async Task<IActionResult> GetData()
        {
            var userId = User?.Identity?.Name ?? "anon";
            var result = await _service.GetDataAsync(userId);
            if (!result.Success)
                return Json(new { data = new List<object>(), error = result.Message });

            // Padroniza o shape p/ o front e inclui token por linha
            try
            {
                // Tenta converter para IEnumerable<Tsistema>
                var list = result.Data as IEnumerable<Tsistema>;
                if (list is not null)
                {
                    var dataTyped = list.Select(r => new
                    {
                        r.Cdsistema,
                        r.Dcsistema,
                        r.Ativo,
                        token = _rowToken.Protect(
                            payload: new RowKeys((r.Cdsistema ?? string.Empty).Trim()),
                            purpose: "Delete",
                            userId: userId,
                            ttl: TimeSpan.FromMinutes(10))
                    });
                    return Json(new { data = dataTyped });
                }

                // Fallback genérico com reflexão (caso o service retorne uma projeção)
                var raw = (result.Data as IEnumerable<object>) ?? Enumerable.Empty<object>();
                var data = raw.Select(o =>
                {
                    string id = GetString(o, "Cdsistema") ?? string.Empty;
                    return new
                    {
                        Cdsistema = id,
                        Dcsistema = GetString(o, "Dcsistema"),
                        Ativo = GetBool(o, "Ativo"),
                        token = _rowToken.Protect(
                            payload: new RowKeys(id.Trim()),
                            purpose: "Delete",
                            userId: userId,
                            ttl: TimeSpan.FromMinutes(10))
                    };
                });
                return Json(new { data });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Falha ao montar retorno do GetData de Tsistema.");
                // Em caso de falha, devolve o data bruto para não quebrar o grid
                return Json(new { data = result.Data });
            }
        }

        // POST: /SEG/Tsistema/UpdateAtivo
        [HttpPost]
        [ValidateAntiForgeryToken]
        [EnableRateLimiting("UpdateAtivoPolicy")]
        [RequirePermission("SEG", "SEG_SISTEMAS", "A")]
        public async Task<IActionResult> UpdateAtivo([FromForm] string id, [FromForm] bool ativo)
        {
            var userId = User?.Identity?.Name ?? "anon";

            // Anti-double click / cooldown curto
            var cooldownKey = $"SEG:Tsistema:UpdateAtivo:{userId}:{id}";
            if (_cache.TryGetValue(cooldownKey, out _))
                return Json(new { success = false, message = "Aguarde um instante antes de alterar novamente." });

            _cache.Set(cooldownKey, 1, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(2)
            });

            var resp = await _service.UpdateAtivoAsync(id, ativo, userId);
            return Json(resp);
        }

        // GET: /SEG/Tsistema/SafeEdit?token=...
        [HttpGet]
        [RequirePermission("SEG", "SEG_SISTEMAS", "A")]
        public async Task<IActionResult> SafeEdit([FromQuery] string token)
        {
            var userId = User?.Identity?.Name ?? "anon";
            var (resp, entidade) = await _service.GetForSafeEditAsync(token, userId);
            if (!resp.Success) return Forbid();
            return View("Edit", entidade!);
        }

        // DTOs padronizados
        public sealed class DeleteByTokenDto { public string Token { get; set; } = string.Empty; }
        public sealed class DeleteBatchDto { public List<string> Tokens { get; set; } = new(); }

        // POST: /SEG/Tsistema/DeleteByToken
        [HttpPost]
        [ValidateAntiForgeryToken]
        [RequirePermission("SEG", "SEG_SISTEMAS", "E")]
        public async Task<IActionResult> DeleteByToken([FromBody] DeleteByTokenDto dto)
        {
            var userId = User?.Identity?.Name ?? "anon";
            var resp = await _service.DeleteByTokenAsync(dto.Token, userId);
            if (!resp.Success) return StatusCode(500, resp);
            return Ok(ApiResponse.Ok("Excluído com sucesso."));
        }

        // POST: /SEG/Tsistema/DeleteBatch
        [HttpPost]
        [ValidateAntiForgeryToken]
        [RequirePermission("SEG", "SEG_SISTEMAS", "E")]
        public async Task<IActionResult> DeleteBatch([FromBody] DeleteBatchDto dto)
        {
            if (dto?.Tokens == null || dto.Tokens.Count == 0)
                return BadRequest(new { success = false, message = "Nenhum token informado." });

            var userId = User?.Identity?.Name ?? "anon";
            int ok = 0, fail = 0;

            foreach (var token in dto.Tokens)
            {
                try
                {
                    var resp = await _service.DeleteByTokenAsync(token, userId);
                    if (resp.Success) ok++; else fail++;
                }
                catch
                {
                    fail++;
                }
            }

            return Ok(new { success = fail == 0, ok, fail });
        }

        // ===== Ações padrão (Create/Edit/Delete tradicionais) =====

        // GET: /SEG/Tsistema/Create
        [HttpGet]
        [RequirePermission("SEG", "SEG_SISTEMAS", "A")]
        public IActionResult Create() => View();

        // POST: /SEG/Tsistema/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [RequirePermission("SEG", "SEG_SISTEMAS", "A")]
        public async Task<IActionResult> Create([Bind("Cdsistema,Dcsistema,Ativo")] Tsistema sistema)
        {
            var resp = await _service.CreateAsync(sistema, ModelState);
            return Json(resp);
        }

        // POST: /SEG/Tsistema/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        [RequirePermission("SEG", "SEG_SISTEMAS", "A")]
        public async Task<IActionResult> Edit(string id, [Bind("Cdsistema,Dcsistema,Ativo")] Tsistema sistema)
        {
            var resp = await _service.EditAsync(id, sistema, ModelState);
            return Json(resp);
        }

        // GET: /SEG/Tsistema/Delete/{id} (confirmação)
        [HttpGet]
        [RequirePermission("SEG", "SEG_SISTEMAS", "E")]
        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();
            var db = HttpContext.RequestServices.GetRequiredService<RhSensoWeb.Data.ApplicationDbContext>();
            var sistema = await db.Tsistema.AsNoTracking().FirstOrDefaultAsync(m => m.Cdsistema == id);
            if (sistema is null) return NotFound();
            return View(sistema);
        }

        // POST: /SEG/Tsistema/Delete/{id} (confirmação)
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [RequirePermission("SEG", "SEG_SISTEMAS", "E")]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var db = HttpContext.RequestServices.GetRequiredService<RhSensoWeb.Data.ApplicationDbContext>();

            try
            {
                var sistema = await db.Tsistema.FindAsync(id);
                if (sistema != null)
                {
                    db.Tsistema.Remove(sistema);
                    await db.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Sistema excluído com sucesso!";
                }
                else
                {
                    TempData["ErrorMessage"] = "Sistema não encontrado.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erro ao excluir sistema {Id}", id);
                TempData["ErrorMessage"] = "Erro ao excluir o sistema. Verifique dependências.";
            }

            return RedirectToAction(nameof(Index));
        }

        // GET: /SEG/Tsistema/HealthCheck
        [HttpGet]
        [RequirePermission("SEG", "SEG_SISTEMAS", "C")]
        public async Task<IActionResult> HealthCheck()
        {
            var resp = await _service.HealthCheckAsync();
            return Json(resp.Success
                ? new { success = true, message = resp.Message, totalSistemas = resp.Data }
                : new { success = false, message = resp.Message });
        }

        // ===== Helpers =====
        private static string? GetString(object obj, string prop)
        {
            var p = obj.GetType().GetProperty(prop, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
            return p?.GetValue(obj)?.ToString();
        }

        private static bool GetBool(object obj, string prop)
        {
            var p = obj.GetType().GetProperty(prop, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
            var v = p?.GetValue(obj);
            if (v is null) return false;
            if (v is bool b) return b;
            if (v is int i) return i != 0;
            if (bool.TryParse(v.ToString(), out var parsed)) return parsed;
            return false;
        }
    }
}
