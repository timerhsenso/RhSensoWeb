﻿// Path: Common/ControllerResponseExtensions.cs
using System.Linq;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace RhSensoWeb.Common
{
    public static class ControllerResponseExtensions
    {
        /// <summary>200 OK com ApiResponse.</summary>
        public static IActionResult OkResp(this Controller controller, string? message = null, object? data = null)
            => controller.Ok(ApiResponse.Ok(message, data));

        /// <summary>400 BadRequest com ApiResponse.</summary>
        public static IActionResult BadResp(this Controller controller, string? message = null, object? data = null)
            => controller.BadRequest(ApiResponse.Fail(message, data));

        /// <summary>400 BadRequest com erros de ModelState (padronizado).</summary>
        public static IActionResult InvalidModel(this Controller controller, string? message = "Dados inválidos.")
            => controller.BadRequest(ApiResponse.Validation(message, controller.ModelState.ToErrorsDictionary()));

        /// <summary>404 NotFound com ApiResponse.</summary>
        public static IActionResult NotFoundResp(this Controller controller, string? message = "Recurso não encontrado.", object? data = null)
            => controller.NotFound(ApiResponse.Fail(message, data));

        /// <summary>201 Created com ApiResponse.</summary>
        public static IActionResult CreatedResp(this Controller controller, string locationUrl, string? message = null, object? data = null)
            => controller.Created(locationUrl, ApiResponse.Ok(message, data));

        /// <summary>Helper: transforma ModelState em dicionário { campo: [erros...] }.</summary>
        public static IDictionary<string, string[]> ToErrorsDictionary(this ModelStateDictionary modelState)
        {
            return modelState
                .Where(kvp => kvp.Value is { Errors.Count: > 0 })
                .ToDictionary(
                    kvp => kvp.Key,
                    kvp => kvp.Value!.Errors.Select(e => string.IsNullOrWhiteSpace(e.ErrorMessage) ? "Erro de validação." : e.ErrorMessage).ToArray()
                );
        }
    }
}
