// wwwroot/js/crud/pages/tsistema.config.js
// Config exata para o Tsistema (SEG), aderente ao que o controller retorna hoje
// JSON de /SEG/Tsistema/GetData vem em lowercase: cdsistema, dcsistema, ativo, editToken, deleteToken

import { builtins } from "/js/crud/page-factory.js";

export default {
  area: "SEG",
  entity: "Tsistema",
  selectors: {
    table: "#tblSistemas",     // mantém o id atual da sua tabela
    modal: "#formModal",       // mantém o id atual do modal
    newButton: "#BtnCreateNew" // mantém o botão atual "Novo"
  },
  endpoints: {
    list: "/SEG/Tsistema/GetData",
    createForm: "/SEG/Tsistema/Create?modal=1",
    safeEditForm: (row, token) => `/SEG/Tsistema/SafeEdit?token=${encodeURIComponent(token || row.editToken || row.EditToken || "")}`,
    updateAtivo: "/SEG/Tsistema/UpdateAtivo",
    deleteByToken: "/SEG/Tsistema/DeleteByToken"
  },
  key: "cdsistema",
  keyParamName: "id",
  columns: [
    { data: "cdsistema", title: "Código" },
    { data: "dcsistema", title: "Descrição" },
    builtins.toggle("ativo", "Ativo"),
    builtins.actions()
  ],
  texts: {
    newTitle: "Novo Sistema",
    editTitle: "Editar Sistema",
    confirmDelete: "Confirma excluir este registro?",
    saved: "Registro salvo com sucesso.",
    deleted: "Excluído com sucesso."
  }
};
