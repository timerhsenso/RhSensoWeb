/**
 * Template Name: INSPINIA - Multipurpose Admin & Dashboard Template
 * By (Author): WebAppLayers
 * Module/App (File Name): Form Select2
 * Version: 4.2.0
 */

if (jQuery().select2) {
    $('[data-toggle="select2"]').select2();
}